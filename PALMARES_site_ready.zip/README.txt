PALMARES — gotowa strona MVP

Pliki do publikacji:
- index.html
- styles.css

Publikacja za 0 € na GitHub Pages:
1. Wejdź na https://github.com i załóż konto albo zaloguj się.
2. Kliknij + w prawym górnym rogu → New repository.
3. Nazwa repozytorium: palmares
4. Ustaw Public.
5. Kliknij Create repository.
6. Kliknij upload an existing file.
7. Wgraj pliki index.html oraz styles.css.
8. Kliknij Commit changes.
9. Wejdź w Settings → Pages.
10. Source: Deploy from a branch.
11. Branch: main, folder: /root.
12. Kliknij Save.
13. Po 1–3 minutach GitHub pokaże link do strony.

Dane kontaktowe ustawione:
WhatsApp: +34 625 032 815
E-mail: paulinapaula720@gmail.com

Uwaga:
Formularz kontaktowy działa jako mailto — otwiera pocztę użytkownika.
Na start to wystarczy. Później możemy podłączyć lepszy formularz.
